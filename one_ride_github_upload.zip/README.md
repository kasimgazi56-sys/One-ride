# ONE RIDE Flutter demo

This is a customer-side UI demo. It does not connect to real drivers, live GPS/maps,
phone authentication, payments, notifications, or an admin backend.
Do not use it for real rides or customer payments.

GitHub Actions can build an Android release APK from this repository.
