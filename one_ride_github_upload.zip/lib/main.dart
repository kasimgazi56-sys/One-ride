import 'package:flutter/material.dart';

void main() => runApp(const OneRideApp());

const Color rideYellow = Color(0xFFFFC400);
const Color rideBlack = Color(0xFF151515);

class OneRideApp extends StatelessWidget {
  const OneRideApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ONE RIDE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: rideYellow,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: rideBlack,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedTab = 0;
  String? lastRide;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onBooked: (ride) {
        setState(() {
          lastRide = ride;
          selectedTab = 1;
        });
      }),
      RidesPage(lastRide: lastRide),
      const ProfilePage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[selectedTab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedTab,
        onDestinationSelected: (index) => setState(() => selectedTab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.two_wheeler), label: 'My Rides'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final ValueChanged<String> onBooked;
  const HomePage({super.key, required this.onBooked});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final pickupController = TextEditingController(text: 'Aligarh Railway Station');
  final dropController = TextEditingController();
  bool booking = false;

  @override
  void dispose() {
    pickupController.dispose();
    dropController.dispose();
    super.dispose();
  }

  int get estimatedFare {
    final chars = pickupController.text.length + dropController.text.length;
    return 30 + (chars % 5) * 10;
  }

  void bookRide() {
    if (dropController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your destination first.')),
      );
      return;
    }
    setState(() => booking = true);
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(Icons.check_circle, color: Colors.green, size: 42),
        title: const Text('Demo ride requested!'),
        content: Text(
          'Your demo booking from ${pickupController.text} to ${dropController.text} has been created. No real driver has been contacted.',
        ),
        actions: [
          FilledButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              widget.onBooked('${pickupController.text} → ${dropController.text}');
            },
            child: const Text('View my ride'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Container(
            color: rideBlack,
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: const BoxDecoration(color: rideYellow, shape: BoxShape.circle),
                      child: const Icon(Icons.two_wheeler, color: rideBlack, size: 28),
                    ),
                    const SizedBox(width: 12),
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('ONE RIDE', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                        Text('YOUR RIDE, YOUR WAY', style: TextStyle(color: rideYellow, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.4)),
                      ],
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notifications will be available in the full app.'))),
                      icon: const Icon(Icons.notifications_none, color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                const Text('Hello, Aligarh!', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                const Text('Where would you like to go?', style: TextStyle(color: Colors.white70, fontSize: 15)),
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(18),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.05), blurRadius: 16, offset: const Offset(0, 5))]),
                child: Column(
                  children: [
                    const Row(children: [Icon(Icons.route, color: rideBlack), SizedBox(width: 8), Text('Book a bike ride', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))]),
                    const SizedBox(height: 18),
                    TextField(
                      controller: pickupController,
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.my_location, color: Colors.green), labelText: 'Pickup location'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: dropController,
                      textCapitalization: TextCapitalization.words,
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.location_on, color: Colors.red), labelText: 'Where to? (destination)'),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(color: const Color(0xFFFFF7D6), borderRadius: BorderRadius.circular(14)),
                      child: Row(
                        children: [
                          const Icon(Icons.currency_rupee, color: rideBlack),
                          const SizedBox(width: 8),
                          const Expanded(child: Text('Demo estimated fare', style: TextStyle(fontWeight: FontWeight.w600))),
                          Text('₹$estimatedFare', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: rideYellow, foregroundColor: rideBlack, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
                        onPressed: booking ? null : bookRide,
                        icon: const Icon(Icons.two_wheeler),
                        label: const Text('BOOK BIKE RIDE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .6)),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text('Demo only • No real booking or payment', style: TextStyle(color: Colors.black54, fontSize: 11)),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text('Why choose ONE RIDE?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Row(
                children: [
                  FeatureTile(icon: Icons.timer_outlined, title: 'Quick', subtitle: 'Booking'),
                  SizedBox(width: 9),
                  FeatureTile(icon: Icons.verified_user_outlined, title: 'Verified', subtitle: 'Drivers'),
                  SizedBox(width: 9),
                  FeatureTile(icon: Icons.currency_rupee, title: 'Fair', subtitle: 'Pricing'),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: rideBlack, borderRadius: BorderRadius.circular(18)),
                child: const Row(
                  children: [
                    Icon(Icons.location_city, color: rideYellow, size: 32),
                    SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Starting in Aligarh', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                      Text('Local rides. Simple booking.', style: TextStyle(color: Colors.white70)),
                    ])),
                    Icon(Icons.arrow_forward, color: rideYellow),
                  ],
                ),
              ),
            ]),
          ),
        ),
      ],
    );
  }
}

class FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const FeatureTile({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 5),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Column(children: [
        Icon(icon, color: rideBlack, size: 27),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 11)),
      ]),
    ),
  );
}

class RidesPage extends StatelessWidget {
  final String? lastRide;
  const RidesPage({super.key, required this.lastRide});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('My Rides', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const SizedBox(height: 18),
      if (lastRide == null)
        const Expanded(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.two_wheeler, size: 60, color: Colors.black26),
          SizedBox(height: 12),
          Text('No rides yet', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          Text('Your bookings will appear here.', style: TextStyle(color: Colors.black54)),
        ])))
      else
        Card(
          child: ListTile(
            leading: const CircleAvatar(backgroundColor: rideYellow, child: Icon(Icons.two_wheeler, color: rideBlack)),
            title: const Text('Demo ride requested', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(lastRide!),
            trailing: const Chip(label: Text('Demo')),
          ),
        ),
    ]),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('My Profile', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const SizedBox(height: 22),
      const CircleAvatar(radius: 42, backgroundColor: rideYellow, child: Icon(Icons.person, size: 48, color: rideBlack)),
      const SizedBox(height: 12),
      const Center(child: Text('ONE RIDE Customer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
      const Center(child: Text('Aligarh, Uttar Pradesh', style: TextStyle(color: Colors.black54))),
      const SizedBox(height: 24),
      const ProfileRow(icon: Icons.phone_outlined, title: 'Phone number', subtitle: 'Login will be added in the next phase'),
      const ProfileRow(icon: Icons.help_outline, title: 'Help & Support', subtitle: 'Support setup pending'),
      const ProfileRow(icon: Icons.shield_outlined, title: 'Safety', subtitle: 'Safety features required before public launch'),
      const ProfileRow(icon: Icons.info_outline, title: 'About ONE RIDE', subtitle: 'Bike taxi demo app • Version 1.0'),
    ],
  );
}

class ProfileRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const ProfileRow({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 5),
    leading: CircleAvatar(backgroundColor: const Color(0xFFFFF2BF), child: Icon(icon, color: rideBlack)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text(subtitle),
  );
}
